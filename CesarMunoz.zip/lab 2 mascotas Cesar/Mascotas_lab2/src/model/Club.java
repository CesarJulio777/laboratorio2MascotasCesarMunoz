package model;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Comparator;

public class Club  implements Serializable ,Comparable <Club>{
	
	private String id;
	private String cluName;
	private String creationDate;
	
	ArrayList <String > petType; 
	
	ArrayList<Owner> owner;

	public Club(String id, String clubName, String creationDate, ArrayList<String> mascota) {
		
		owner=new ArrayList<Owner>();
		this.id = id;
		this.cluName= clubName;
		this.creationDate = creationDate;
		this.petType = mascota;
	}
	


	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id=id;
	}

	public String getClubName() {
		return  cluName;
	}

	public void setName(String name) {
		this.cluName=cluName ;
	}

	public String getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(String creationDate) {
		this.creationDate = creationDate;
	}

	public ArrayList<String> getPetType() {
		return petType;
	}

	public void setPetType(ArrayList<String> petType) {
		this.petType = petType;
	}

	public ArrayList<Owner> getOwner() {
		return owner;
	}

	public void setOwner(ArrayList<Owner> owner) {
		this.owner = owner;
	}
	
	
	// agregar un due�o
	
public void addOwner( Owner a) throws Exception  {
		
		if(owner!=null) {
			
			for (int i = 0; i < owner.size();i++) {
				
				if(owner.equals(a.getIdOwner())) {
					throw new Exception(" there is already an owner registered with this id");
				}else {
					owner.add(a);
				}
			}
			
		}
	}
//	


	@Override
	public String toString() {
		return "Club [idClub=" + id + ", name=" +  cluName + ", creationDate=" + creationDate + ", petType=" + petType
				+ ", owner=" + owner + "]";
	}


	
	@Override
	public int compareTo(Club o) {
		
		return cluName.compareTo(o.getClubName());
	}


	
	/**
	 * Metodo que deserializa los owners 
	 * @param 
	 * @return : return the owner
	 */
	
	 public ArrayList<Owner> leerArchivo() throws FileNotFoundException, ClassNotFoundException {
		FileInputStream fileInStr = null;
		ObjectInputStream entrada = null;
		ArrayList<Owner> owner = null;
		try {

			fileInStr = new FileInputStream("C:\\Desktop\\laboratorioDosMascotas_cesar\\Mascotas_lab2\\src\\Data");
			entrada = new ObjectInputStream(fileInStr);

			owner= (ArrayList<Owner>) entrada.readObject();

		} catch (FileNotFoundException e) {
			owner=new ArrayList<Owner>();
		  } catch (ClassNotFoundException e) {
	            System.out.println(e.getMessage());
	        } catch (IOException e) {
	            System.out.println(e.getMessage());
	        } finally {
	            try {
	                if (fileInStr != null) {
	                	fileInStr.close();
	                }
	                if (entrada != null) {
	                    entrada.close();
	                }
	            } catch (IOException e) {
	                System.out.println(e.getMessage());
	            }
	        }	
		return owner;
	}
	
	 
	 
	 /**
		 * Metodo que deserializa los owners 
		 * @param 
		 * @return : return the owner
		 */
		
	 
	public void serializar (ArrayList<Owner> owner)throws FileNotFoundException, IOException, ClassNotFoundException{
		FileOutputStream fileOutS = null;
		ObjectOutputStream salida = null;
		ArrayList<Owner> ow= leerArchivo();
		for (int i = 0; i <ow.size(); i++) {
			if(ow.get(i).getIdOwner().equalsIgnoreCase(owner.get(i).getIdOwner())) {
				ow.remove(i);
			}
		}
		ow.addAll(owner);

		try
		{
			fileOutS = new FileOutputStream("C:\\Desktop\\laboratorioDosMascotas_cesar\\Mascotas_lab2\\src\\Data");
			salida = new ObjectOutputStream(fileOutS);		
			salida.writeObject(owner);
		}catch(FileNotFoundException e)
		{
			System.out.println(e.getMessage());
		}catch(IOException e)
		{
			System.out.println(e.getMessage());
		}finally
		{
			try {
				if (owner != null)
					fileOutS.close();
				if (salida != null)
					salida.close();
			} catch (IOException e) {
				System.out.println(e.getMessage());
			}
		}
	}
	
	
    
	

	      
	}
	

	


 

