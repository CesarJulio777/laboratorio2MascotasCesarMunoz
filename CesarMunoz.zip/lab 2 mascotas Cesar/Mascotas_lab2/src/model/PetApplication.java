package model;

import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class PetApplication  {
	
	private ArrayList<Club> club ;

	public PetApplication(ArrayList<Club> club) {
	
		this.club = club;
	}
	
	
	/**
	 * Metodo que crea el archivo de club por medio de archivos planos 
	 * @param  club:  
	 * @return : 
	 */
	
	
	public  void crearArchivo(ArrayList<Club> club) {
		FileWriter flwriter = null;
		try {
			
     	flwriter = new FileWriter("C:\\Desktop\\laboratorioDosMascotas_cesar\\Mascotas_lab2\\src\\Data"); 
			
			BufferedWriter bfwriter = new BufferedWriter(flwriter);
			for (Club clubes : club) {
				
				bfwriter.write(clubes.getPetType() + "," + clubes.getClubName() + "," + clubes.getCreationDate()
						+ "," +clubes.getId() + ","  + "\n");
			}
		
			bfwriter.close();
			System.out.println("file created successfully...");
 
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (flwriter != null) {
				try {
					flwriter.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}


	
    
	
	
	

}
