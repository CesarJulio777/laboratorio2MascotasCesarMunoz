package model;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;


import org.omg.PortableServer.ID_ASSIGNMENT_POLICY_ID;

public class Owner implements   Serializable ,Comparable<Owner>  {
	
	private String idOwner;
	private String name;
	private String birthdate;
	private String lastName;
	private String kindOfMascota;
	
     ArrayList<Pet> pets;

	public Owner(String idOwner, String name,String birthdate, String apellido, String lastName, String kindOfMascota, ArrayList<Pet> pets) {
		
		pets= new ArrayList<Pet>();
		this.idOwner = idOwner;
		this.name = name;
		this.birthdate=birthdate;
		this.lastName= lastName;
		this.kindOfMascota = kindOfMascota;
	
	}

	public String getIdOwner() {
		return idOwner;
	}

	public void setIdOwner(String idOwner) {
		this.idOwner = idOwner;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getBirthdate() {
		return birthdate;
	}

	public void setBirthdate(String birthdate) {
		this.birthdate = birthdate;
	}

	public String getLastName() {
		return lastName;
	}

	public void setSurName(String surName) {
		this.lastName= lastName;
	}

	public String getKindOfMascota() {
		return kindOfMascota;
	}

	public void setKindOfMascota(String kindOfMascota) {
		this.kindOfMascota = kindOfMascota;
	}

	public ArrayList<Pet> getPets() {
		return pets;
	}

	public void setPets(ArrayList<Pet> pets) {
		this.pets = pets;
	}
	
	//agregar mascotas 
	
	public void addPets (Pet a) throws Exception {
		if(pets !=null ) {
			for (int i = 0; i < pets.size(); i++) {
				if(pets.get(i).getName().equals(a.getName())) {
					
				
					throw new Exception ("there is already a pet registered with this name");
				}	else {
						pets.add(a);
					}
				}
				
			}
		}
		

	@Override
	public String toString() {
		return "Owner [idOwner=" + idOwner + ", name=" + name + ", birthdate=" + birthdate + ", surName=" + lastName
				+ ", kindOfMascota=" + kindOfMascota + ", pets=" + pets + "]";
	}

	@Override
	public int compareTo(Owner o) {
		
		return name.compareTo(o.getName());
	}

	
	
	/**
	 * Metodo que compara a dos due�os  por su apellido.
	 * @param n : apellido del due�o a comparar.
	 * @return : El valor -1 si el due�o es menor, 0 si es igual y 1 si es mayor.
	 */
	public int compareToALastName(String n) {
		int c = 0;

		if (lastName.compareTo(n) == 1) {
			c = 1;
		} else if (lastName.compareTo(n) == -1) {
			c = -1;
		} else {
			c = 0;
		}

		return c;
	}
	
		
	/**
	 * Metodo que compara a dos due�os  por su identificacion
	 * @param n :  identificacion del due�o a comparar.
	 * @return : El valor -1 si el due�o es menor, 0 si es igual y 1 si es mayor.
	 */
	

	public int compareToId( String   n) {
		int c = 0;

		if (idOwner.compareTo(n) == 1) {
			c = 1;
		} else if (idOwner.compareTo(n) == -1) {
			c = -1;
		} else {
			c = 0;
		}

		return c;
	}
	
	
	// pendiente los comparardores
	
	
	
	
	
	
	/**
	 * Metodo que deserializa los Pet
	 * @param 
	 * @return : return the pet
	 */
	
	 public ArrayList<Pet> leerArchivo() throws FileNotFoundException, ClassNotFoundException {
		FileInputStream fileInStr = null;
		ObjectInputStream entrada = null;
		ArrayList<Pet> pets = null;
		try {

			fileInStr = new FileInputStream("C:\\Desktop\\laboratorioDosMascotas_cesar\\Mascotas_lab2\\src\\Data");
			entrada = new ObjectInputStream(fileInStr);

			pets= (ArrayList<Pet>) entrada.readObject();

		} catch (FileNotFoundException e) {
			pets=new ArrayList<Pet>();
		  } catch (ClassNotFoundException e) {
	            System.out.println(e.getMessage());
	        } catch (IOException e) {
	            System.out.println(e.getMessage());
	        } finally {
	            try {
	                if (fileInStr != null) {
	                	fileInStr.close();
	                }
	                if (entrada != null) {
	                    entrada.close();
	                }
	            } catch (IOException e) {
	                System.out.println(e.getMessage());
	            }
	        }	
		return pets;
	}
	
	 
	 
	 /**
		 * Metodo que deserializa los Pet 
		 * @param 
		 * @return : return the pets
		 */
		
	 
	public void serializar (ArrayList<Pet> pets)throws FileNotFoundException, IOException, ClassNotFoundException{
		FileOutputStream fileOutS = null;
		ObjectOutputStream salida = null;
		ArrayList<Pet> ow= leerArchivo();
		for (int i = 0; i <ow.size(); i++) {
			if(ow.get(i).getIdPet().equalsIgnoreCase(ow.get(i).getIdPet())) {
				ow.remove(i);
			}
		}
		ow.addAll(pets);

		try
		{
			fileOutS = new FileOutputStream("C:\\Desktop\\laboratorioDosMascotas_cesar\\Mascotas_lab2\\src\\Data");
			salida = new ObjectOutputStream(fileOutS);		
			salida.writeObject(pets);
		}catch(FileNotFoundException e)
		{
			System.out.println(e.getMessage());
		}catch(IOException e)
		{
			System.out.println(e.getMessage());
		}finally
		{
			try {
				if (pets != null)
					fileOutS.close();
				if (salida != null)
					salida.close();
			} catch (IOException e) {
				System.out.println(e.getMessage());
			}
		}
	}
	
	
    
	
	
	
	
	
	
	
	
}
	


