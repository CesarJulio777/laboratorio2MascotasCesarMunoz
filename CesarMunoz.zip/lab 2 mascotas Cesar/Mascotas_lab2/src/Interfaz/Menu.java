package Interfaz;

import model.PetApplication;

public class Menu {

	public static void main(String[] args) {
		
		
		
	}

}
