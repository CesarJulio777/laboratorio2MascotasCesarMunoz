package model;

import java.io.Serializable;
import java.util.Comparator;

public class Pet implements Serializable , Comparable<Pet> {
	
	private String idPet;
	private String name;
	private String birthdate;
	private char genero;
	private String gender;
	private String kindOfPet;
	
	public Pet(String idPet, String name, String birthdate, char genero, String gender, String kindOfPet) {
		
		this.idPet = idPet;
		this.name = name;
		this.birthdate = birthdate;
		this.genero = genero;
		this.gender = gender;
		this.kindOfPet = kindOfPet;
	}
	public  String getIdPet() {
		return idPet;
	}
	public void setIdPet(String idPet) {
		this.idPet = idPet;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getBirthdate() {
		return birthdate;
	}
	public void setBirthdate(String birthdate) {
		this.birthdate = birthdate;
	}
	public char getGenero() {
		return genero;
	}
	public void setGenero(char genero) {
		this.genero = genero;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getKindOfPet() {
		return kindOfPet;
	}
	public void setKindOfPet(String kindOfPet) {
		this.kindOfPet = kindOfPet;
	}
	@Override
	public String toString() {
		return "Pet [idPet=" + idPet + ", name=" + name + ", birthdate=" + birthdate + ", genero=" + genero
				+ ", gender=" + gender + ", kindOfPet=" + kindOfPet + "]";
	}
	@Override
	public int compareTo(Pet o) {
		
		return name.compareTo(o.getName());
	}
	

	
	}
	
	


